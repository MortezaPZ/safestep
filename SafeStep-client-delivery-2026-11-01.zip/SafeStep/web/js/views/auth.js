/** صفحه‌ی ورود و ثبت‌نام. */
import api from '../api.js';
import { el, render, toast } from '../ui.js';
import { toEnDigits } from '../format.js';

export function mountAuth(container, { onSuccess }) {
  let mode = 'login';

  const errorBox = el('div.field__error', { role: 'alert' });
  const phoneInput = el('input.input', {
    type: 'tel',
    id: 'auth-phone',
    inputmode: 'numeric',
    placeholder: '۰۹۱۲۳۴۵۶۷۸۹',
    autocomplete: 'tel',
    dir: 'ltr',
  });
  const passwordInput = el('input.input', {
    type: 'password',
    id: 'auth-password',
    placeholder: '••••••••',
    autocomplete: 'current-password',
  });
  const nameInput = el('input.input', {
    type: 'text',
    id: 'auth-name',
    placeholder: 'نام و نام خانوادگی',
    autocomplete: 'name',
  });
  const roleSelect = el(
    'select.select',
    { id: 'auth-role' },
    el('option', { value: 'primary', text: 'کاربر اصلی — من می‌خواهم مستقل بیرون بروم' }),
    el('option', { value: 'guardian', text: 'ناظر — می‌خواهم مراقب کسی باشم' }),
  );

  const nameField = el(
    'div.field',
    {},
    el('label.field__label', { for: 'auth-name', text: 'نام کامل' }),
    nameInput,
  );

  const roleField = el(
    'div.field',
    {},
    el('label.field__label', { for: 'auth-role', text: 'نقش شما' }),
    roleSelect,
  );

  const otpInput = el('input.input', {
    type: 'text',
    id: 'auth-otp',
    inputmode: 'numeric',
    placeholder: 'کد ۶ رقمی',
    dir: 'ltr',
  });
  const otpHint = el('p.text-xs.text-muted', { text: '' });
  const otpField = el(
    'div.field.hidden',
    {},
    el('label.field__label', { for: 'auth-otp', text: 'کد تأیید پیامک' }),
    otpInput,
    otpHint,
  );

  let publicCfg = { phoneVerificationRequired: false, smsDriver: 'console' };
  api.publicConfig().then((cfg) => {
    publicCfg = cfg ?? publicCfg;
    otpField.classList.toggle('hidden', !(publicCfg.phoneVerificationRequired && mode === 'register'));
    otpHint.textContent = publicCfg.smsDriver === 'console'
      ? 'کد در لاگ سرور چاپ شد (حالت توسعه)'
      : '';
  }).catch(() => {});

  const loginTab = el('button.auth-tab', {
    type: 'button',
    role: 'tab',
    ariaSelected: 'true',
    text: 'ورود',
    onClick: () => setMode('login'),
  });

  const registerTab = el('button.auth-tab', {
    type: 'button',
    role: 'tab',
    ariaSelected: 'false',
    text: 'ثبت‌نام',
    onClick: () => setMode('register'),
  });

  const submitBtn = el('button.btn.btn--block', {
    type: 'submit',
    text: 'ورود',
  });

  function setMode(next) {
    mode = next;
    const isLogin = next === 'login';

    loginTab.setAttribute('aria-selected', String(isLogin));
    registerTab.setAttribute('aria-selected', String(!isLogin));
    nameField.classList.toggle('hidden', isLogin);
    roleField.classList.toggle('hidden', isLogin);
    otpField.classList.toggle('hidden', isLogin || !publicCfg.phoneVerificationRequired);
    submitBtn.textContent = isLogin ? 'ورود' : 'ساخت حساب';
    passwordInput.setAttribute('autocomplete', isLogin ? 'current-password' : 'new-password');
    errorBox.textContent = '';
  }

  async function submit(event) {
    event.preventDefault();
    errorBox.textContent = '';

    const phone = toEnDigits(phoneInput.value).replace(/\D/g, '');
    const password = passwordInput.value;

    if (!phone || !password) {
      errorBox.textContent = 'شماره موبایل و رمز عبور را وارد کنید.';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = mode === 'login' ? 'در حال ورود…' : 'در حال ساخت حساب…';

    try {
      let verificationToken;
      if (mode === 'register' && publicCfg.phoneVerificationRequired) {
        const code = toEnDigits(otpInput.value).replace(/\D/g, '');
        if (!code) {
          const sent = await api.requestOtp(phone, 'register');
          errorBox.textContent = sent.hint || 'کد ارسال شد. پس از وارد کردن کد دوباره ثبت‌نام کنید.';
          submitBtn.disabled = false;
          submitBtn.textContent = 'ساخت حساب';
          return;
        }
        const verified = await api.verifyOtp(phone, code, 'register');
        verificationToken = verified.verificationToken;
      }

      const session =
        mode === 'login'
          ? await api.login(phone, password)
          : await api.register({
              phone,
              password,
              fullName: nameInput.value.trim(),
              role: roleSelect.value,
              verificationToken,
            });

      toast('خوش آمدید', session.user.fullName);
      onSuccess(session);
    } catch (error) {
      // خطاهای اعتبارسنجی فیلد‌به‌فیلد را هم نشان می‌دهیم
      const details = error.details?.map((d) => d.message).join(' · ');
      errorBox.textContent = details || error.message || 'ورود ناموفق بود.';
      submitBtn.disabled = false;
      submitBtn.textContent = mode === 'login' ? 'ورود' : 'ساخت حساب';
    }
  }

  const form = el(
    'form',
    { onSubmit: submit, novalidate: 'novalidate' },
    nameField,
    el(
      'div.field',
      {},
      el('label.field__label', { for: 'auth-phone', text: 'شماره موبایل' }),
      phoneInput,
    ),
    el(
      'div.field',
      {},
      el('label.field__label', { for: 'auth-password', text: 'رمز عبور' }),
      passwordInput,
    ),
    roleField,
    otpField,
    errorBox,
    submitBtn,
  );

  const card = el(
    'div.auth-card',
    {},
    el(
      'div.brand.mb-4',
      {},
      el('span.brand__mark', { text: '🚶', ariaHidden: 'true' }),
      el(
        'span',
        {},
        el('div', { text: 'هم‌قدم' }),
        el('div.brand__sub', { text: 'ایمنی، بدون از دست دادن استقلال' }),
      ),
    ),
    el('div.auth-tabs', { role: 'tablist' }, loginTab, registerTab),
    form,
  );

  setMode('login');
  render(container, el('div.auth-screen', {}, card));

  phoneInput.focus();

  return () => {};
}

export default mountAuth;
