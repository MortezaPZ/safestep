/**
 * پوسته‌ی اپلیکیشن: احراز هویت، ناوبری، اتصال زنده و مسیریابی بین نماها.
 *
 * تب‌های نمایش‌داده‌شده به رابطه‌های واقعی کاربر بستگی دارد، نه به ستون
 * role در دیتابیس: کسی که هم کاربر اصلی است و هم مراقب مادرش، هر دو
 * دسته تب را می‌بیند. نقش در این محصول یک برچسب ثابت نیست، یک رابطه است.
 */
import api, { loadSession, getAccessToken, clearSession, patchStoredSettings } from './api.js';
import realtime, { WS_EVENTS, CONNECTION_LABELS } from './realtime.js';
import { el, render, toast, $, applyTheme, getTheme, cycleTheme, THEME_ICONS, THEME_LABELS } from './ui.js';
import { faNumber, initials } from './format.js';
import { t } from './i18n.js';
import { mountAuth } from './views/auth.js';
import { mountDashboard } from './views/dashboard.js';
import { mountGuardian } from './views/guardian.js';
import { mountAlerts } from './views/alerts.js';
import { mountFamily } from './views/family.js';
import { mountZones } from './views/zones.js';
import { mountHistory } from './views/history.js';
import { mountSettings } from './views/settings.js';
import { mountDemo } from './views/demo.js';
import { mountAdmin } from './views/admin.js';

const root = $('#root');

/** وضعیت سراسری اپ. */
const state = {
  user: null,
  settings: null,
  links: { guardians: [], primaries: [] },
  unreadCount: 0,
  currentView: null,
  currentParams: {},
  cleanup: null,
};

/* ─────────────────────── تعریف تب‌ها ─────────────────────── */

const VIEWS = {
  admin: { labelKey: 'navAdmin', icon: '🛡️', mount: mountAdmin, forAdmin: true },
  dashboard: { labelKey: 'navDashboard', icon: '🏠', mount: mountDashboard, forPrimary: true },
  guardian: { labelKey: 'navGuardian', icon: '👀', mount: mountGuardian, forGuardian: true },
  alerts: { labelKey: 'alerts', icon: '🔔', mount: mountAlerts, always: true, badge: true },
  zones: { labelKey: 'navZones', icon: '📍', mount: mountZones, forGuardian: true },
  family: { labelKey: 'navFamily', icon: '👨‍👩‍👧', mount: mountFamily, always: true },
  history: { labelKey: 'navHistory', icon: '🗺️', mount: mountHistory, forHistory: true },
  demo: { labelKey: 'navDemo', icon: '🎬', mount: mountDemo, forPrimary: true },
  settings: { labelKey: 'navSettings', icon: '⚙️', mount: mountSettings, forPrimary: true, forGuardian: true },
};

/**
 * تعیین تب‌های قابل نمایش.
 * ادمین تب‌های موقعیت‌محور را نمی‌بیند مگر خودش هم رابطه‌ی سرپرستی داشته باشد.
 */
function visibleViews() {
  const isAdmin = state.user?.role === 'admin';
  const isPrimary = state.user?.role === 'primary';
  const isGuardian = state.user?.role === 'guardian' || state.links.primaries.length > 0;

  return Object.entries(VIEWS).filter(([, view]) => {
    // مدیر فقط پنل مدیریت را می‌بیند. ناظر تنظیمات و محدودهٔ خودش را دارد.
    if (isAdmin) return view.forAdmin === true;
    if (view.forAdmin) return isAdmin;
    if (view.always) return true;
    if (view.forHistory) return isPrimary || isGuardian;
    if (view.forPrimary && isPrimary) return true;
    if (view.forGuardian && isGuardian) return true;
    return false;
  });
}

/** نمای پیش‌فرض بر اساس نقش. */
function defaultView() {
  if (state.user?.role === 'admin') return 'admin';
  if (state.user?.role === 'guardian' || state.links.primaries.length > 0) {
    return state.user?.role === 'primary' ? 'dashboard' : 'guardian';
  }
  return 'dashboard';
}

/* ─────────────────────── سربرگ ─────────────────────── */

let connectionChip = null;
let tabsContainer = null;

function renderHeader() {
  const theme = getTheme();

  connectionChip = el('span.chip', { text: '◐ در حال اتصال…' });
  tabsContainer = el('div.nav-tabs', { role: 'tablist', ariaLabel: 'ناوبری اصلی' });

  const header = el(
    'header.app-header',
    {},
    el(
      'div.brand',
      {},
      el('img.brand__mark', {
        src: 'assets/logo-hamghadam.jpg',
        alt: 'لوگوی هم‌قدم',
      }),
      el(
        'span',
        {},
        el('div', { text: 'هم‌قدم' }),
        el('div.brand__sub', { text: 'ایمنی، بدون از دست دادن استقلال' }),
      ),
    ),
    el('div.header-spacer'),
    connectionChip,
    el('button.icon-btn', {
      type: 'button',
      text: THEME_ICONS[theme],
      title: THEME_LABELS[theme],
      ariaLabel: `تغییر تم — فعلاً ${THEME_LABELS[theme]}`,
      onClick: (event) => {
        const next = cycleTheme();
        event.currentTarget.textContent = THEME_ICONS[next];
        event.currentTarget.title = THEME_LABELS[next];
        event.currentTarget.setAttribute('aria-label', `تغییر تم — فعلاً ${THEME_LABELS[next]}`);
      },
    }),
    el('span.avatar', {
      text: initials(state.user.fullName),
      title: state.user.fullName,
      style: { background: state.user.avatarColor ?? 'var(--accent)' },
    }),
    el('button.icon-btn', {
      type: 'button',
      text: 'خروج',
      title: 'خروج از حساب',
      ariaLabel: 'خروج از حساب',
      onClick: () => doLogout(),
    }),
  );

  return { header, tabsContainer };
}

function renderTabs() {
  if (!tabsContainer) return;

  render(
    tabsContainer,
    ...visibleViews().map(([key, view]) =>
      el(
        'button.nav-tab',
        {
          type: 'button',
          role: 'tab',
          ariaSelected: String(key === state.currentView),
          onClick: () => navigate(key),
        },
        el('span', { text: view.icon, ariaHidden: 'true' }),
        el('span', { text: t(view.labelKey) }),
        view.badge && state.unreadCount > 0
          ? el('span.nav-tab__badge', { text: faNumber(state.unreadCount) })
          : null,
      ),
    ),
  );
}

/* ─────────────────────── مسیریابی ─────────────────────── */

let viewContainer = null;

function navigate(viewKey, params = {}) {
  const view = VIEWS[viewKey];
  if (!view) return;
  if (state.user && !visibleViews().some(([key]) => key === viewKey)) {
    viewKey = defaultView();
  }

  const nextView = VIEWS[viewKey];
  if (!nextView) return;

  // پاک‌سازی نمای قبلی — بدون این، شنونده‌های WebSocket و نقشه‌ها نشت می‌کنند
  state.cleanup?.();
  state.cleanup = null;

  state.currentView = viewKey;
  state.currentParams = params;

  renderTabs();
  window.location.hash = viewKey;

  viewContainer.replaceChildren();
  state.cleanup = nextView.mount(viewContainer, buildContext(), params);

  // پس از تعویض نما، تمرکز به ابتدای محتوا می‌رود تا کاربر صفحه‌خوان گم نشود
  viewContainer.focus?.();
  requestAnimationFrame(() => {
    window.dispatchEvent(new Event('resize'));
    setTimeout(() => window.dispatchEvent(new Event('resize')), 150);
  });
}

/** بافتی که به همه‌ی نماها داده می‌شود. */
function buildContext() {
  return {
    user: state.user,
    settings: state.settings,
    links: state.links,
    navigate,
    logout: doLogout,
    setUnreadCount(count) {
      state.unreadCount = count;
      renderTabs();
    },
    updateSettings(settings) {
      state.settings = settings;
      patchStoredSettings(settings);
    },
    async refreshRole() {
      await loadLinks();
      renderTabs();
    },
  };
}

/* ─────────────────────── داده‌ی پایه ─────────────────────── */

async function loadLinks() {
  try {
    const links = await api.guardianships();
    state.links = { guardians: links.guardians ?? [], primaries: links.primaries ?? [] };
  } catch {
    state.links = { guardians: [], primaries: [] };
  }
}

async function loadUnreadCount() {
  try {
    const result = await api.alerts({ limit: 1 });
    state.unreadCount = result.unreadCount ?? 0;
  } catch {
    state.unreadCount = 0;
  }
}

/* ─────────────────────── اتصال زنده ─────────────────────── */

function updateConnectionChip(connectionState) {
  if (!connectionChip) return;

  const meta = CONNECTION_LABELS[connectionState] ?? CONNECTION_LABELS.disconnected;
  connectionChip.className = `chip ${meta.className}`;
  connectionChip.textContent = `${meta.dot} ${meta.text}`;
}

function setupRealtime() {
  realtime.on('connection', updateConnectionChip);

  /**
   * نوتیفیکیشن درون‌برنامه‌ای.
   * این همان مسیری است که وقتی کلید FCM تنظیم نشده باشد، تحویل را انجام
   * می‌دهد — و همان مسیری که تأخیر زیر دو ثانیه‌ی دمو را تضمین می‌کند.
   */
  realtime.on(WS_EVENTS.NOTIFICATION, (payload) => {
    toast(payload.title, payload.body, { severity: payload.severity });
  });

  realtime.on(WS_EVENTS.ALERT_NEW, (alert) => {
    if (alert.isResolution) return;
    // شمارنده‌ی نخوانده‌ها فقط برای هشدارهای مربوط به دیگران بالا می‌رود
    state.unreadCount += 1;
    renderTabs();
  });

  realtime.on(WS_EVENTS.SHARING_CHANGED, (payload) => {
    if (payload.userId === state.user?.id) return;
    toast(
      payload.sharingEnabled ? 'اشتراک موقعیت روشن شد' : 'موقعیت مخفی شد',
      payload.sharingEnabled
        ? 'موقعیت دوباره در دسترس است.'
        : 'کاربر اشتراک‌گذاری موقعیت را خاموش کرد.',
    );
  });

  realtime.connect(getAccessToken());
}

/* ─────────────────────── ورود و خروج ─────────────────────── */

async function doLogout() {
  state.cleanup?.();
  realtime.disconnect();

  try {
    await api.logout();
  } catch {
    clearSession();
  }

  state.user = null;
  if (window.location.hash) window.location.hash = '';
  showAuth();
}

function showAuth() {
  render(root, el('div'));
  mountAuth(root, {
    onSuccess: async (session) => {
      state.user = session.user;
      state.settings = session.settings;
      await startApp();
    },
  });
}

/* ─────────────────────── راه‌اندازی ─────────────────────── */

async function startApp() {
  await Promise.all([loadLinks(), loadUnreadCount()]);

  const { header } = renderHeader();

  viewContainer = el('div', { id: 'view', tabindex: '-1' });

  const verifyBanner =
    state.user?.role !== 'admin' &&
    state.user?.verificationStatus &&
    state.user.verificationStatus !== 'verified'
      ? el('div.verify-banner', {
          text: 'مدارک هنوز تأیید نشده. تا تأیید مدیر، ارسال موقعیت، محدوده امن، حالت نمایش و دکمه اضطراری قفل است.',
        })
      : null;

  render(
    root,
    el(
      'div.app-shell',
      {},
      el('a.skip-link', { href: '#view', text: 'پرش به محتوای اصلی' }),
      header,
      el(
        'main.app-main',
        { id: 'main' },
        verifyBanner,
        el('div.mb-4', {}, tabsContainer),
        viewContainer,
      ),
    ),
  );

  setupRealtime();

  // ثبت این مرورگر به‌عنوان یک دستگاه، تا ساختار FCM از همین‌جا هم تغذیه شود
  api
    .registerDevice({ platform: 'web', deviceName: 'مرورگر وب' })
    .catch(() => {});

  const fromHash = window.location.hash.replace('#', '');
  const allowed = new Set(visibleViews().map(([key]) => key));
  const initial = fromHash && allowed.has(fromHash) ? fromHash : defaultView();

  renderTabs();
  requestAnimationFrame(() => {
    navigate(initial);
  });
}

/* ─────────────────────── نقطه‌ی شروع ─────────────────────── */

function boot() {
  try {
    applyTheme(getTheme());

    const session = loadSession();

    if (session?.accessToken) {
      state.user = session.user;
      state.settings = session.settings;

      api
        .me()
        .then((result) => {
          state.user = result.user;
          state.settings = result.settings;
          startApp();
        })
        .catch(() => {
          clearSession();
          showAuth();
        });
    } else {
      showAuth();
    }
  } catch (error) {
    console.error(error);
    if (root) {
      render(
        root,
        el('div.auth-screen', {}, el('div.auth-card', {},
          el('h1', { text: 'داشبورد بارگذاری نشد' }),
          el('p', { text: String(error.message || error) }),
        )),
      );
    }
  }
}

// نشست منقضی‌شده در میانه‌ی کار
window.addEventListener('safestep:session-expired', () => {
  toast('نشست منقضی شد', 'لطفاً دوباره وارد شوید.', { severity: 'warning' });
  state.cleanup?.();
  realtime.disconnect();
  showAuth();
});

// ناوبری با دکمه‌ی back مرورگر
window.addEventListener('hashchange', () => {
  const key = window.location.hash.replace('#', '');
  if (VIEWS[key] && key !== state.currentView && state.user) navigate(key);
});

boot();
