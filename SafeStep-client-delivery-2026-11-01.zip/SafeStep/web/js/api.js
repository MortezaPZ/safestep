/**
 * کلاینت REST.
 *
 * دو مسئولیت اصلی:
 *   ۱) نگهداری توکن‌ها و تازه‌سازی خودکار access token هنگام انقضا
 *   ۲) تبدیل خطاهای HTTP به خطای جاوااسکریپت با پیام فارسیِ سرور
 *
 * تازه‌سازی به‌صورت «یک بار برای همه» انجام می‌شود: اگر چند درخواست
 * همزمان با ۴۰۱ برگردند، تنها یک درخواست refresh فرستاده می‌شود و بقیه
 * منتظر همان می‌مانند. بدون این، هر بار انقضای توکن یک رگبار درخواست
 * refresh تولید می‌کرد که سرور همه را جز اولی رد می‌کند.
 */

const BASE = '/api/v1';
const STORAGE_KEY = 'safestep.session';

class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/* ─────────────────────────── نگهداری نشست ─────────────────────────── */

let session = null;
let refreshPromise = null;

/** خواندن نشست ذخیره‌شده هنگام بارگذاری صفحه. */
export function loadSession() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const saved = raw ? JSON.parse(raw) : null;
    session = saved ? {
      accessToken: saved.accessToken,
      user: saved.user,
      settings: saved.settings ?? null,
    } : null;
    if (saved?.refreshToken) localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } catch {
    session = null;
  }
  return session;
}

export function saveSession(data) {
  session = {
    accessToken: data.accessToken,
    user: data.user,
    settings: data.settings ?? session?.settings ?? null,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  return session;
}

export function clearSession() {
  session = null;
  localStorage.removeItem(STORAGE_KEY);
}

export const getSession = () => session;
export const getUser = () => session?.user ?? null;
export const getAccessToken = () => session?.accessToken ?? null;
export const isLoggedIn = () => Boolean(session?.accessToken);

/** به‌روزرسانی تنظیمات ذخیره‌شده بدون دست زدن به توکن‌ها. */
export function patchStoredSettings(settings) {
  if (!session) return;
  session.settings = settings;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
}

/* ─────────────────────────── درخواست ─────────────────────────── */

async function parseResponse(response) {
  const text = await response.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
}

async function doFetch(path, { method = 'GET', body, query, auth = true } = {}) {
  const url = new URL(BASE + path, window.location.origin);

  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.set(key, value);
      }
    }
  }

  const headers = {};
  headers['X-Client-Kind'] = 'web';
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth && session?.accessToken) headers.Authorization = `Bearer ${session.accessToken}`;

  let response;
  try {
    response = await fetch(url, {
      method,
      headers,
      credentials: 'same-origin',
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, 'NETWORK', 'ارتباط با سرور برقرار نشد. چند لحظه دیگر دوباره تلاش کنید.');
  }

  const data = await parseResponse(response);

  if (!response.ok) {
    const error = data?.error ?? {};
    throw new ApiError(
      response.status,
      error.code ?? 'UNKNOWN',
      error.message ?? 'ارتباط با سرور برقرار نشد.',
      error.details,
    );
  }

  return data;
}

function isTransient(error) {
  if (!error || typeof error.status !== 'number') return true;
  return error.status === 0 || error.status === 429 || error.status >= 500;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** تازه‌سازی توکن — تنها یک درخواست همزمان مجاز است. */
async function refreshAccessToken() {
  if (!session?.accessToken) throw new ApiError(401, 'UNAUTHORIZED', 'نشست شما منقضی شده است.');

  if (!refreshPromise) {
    refreshPromise = doFetch('/auth/refresh', {
      method: 'POST',
      auth: false,
    })
      .then((data) => {
        saveSession({ ...data, settings: session?.settings });
        return data;
      })
      .finally(() => {
        refreshPromise = null;
      });
  }

  return refreshPromise;
}

/**
 * درخواست با تازه‌سازی خودکار.
 * فقط یک بار تلاش مجدد می‌کند؛ اگر باز هم ۴۰۱ شد، نشست واقعاً باطل است.
 */
async function requestOnce(path, options = {}) {
  try {
    return await doFetch(path, options);
  } catch (error) {
    const canRetry = error.status === 401 && options.auth !== false && session?.accessToken;
    if (!canRetry) throw error;

    try {
      await refreshAccessToken();
    } catch {
      clearSession();
      window.dispatchEvent(new CustomEvent('safestep:session-expired'));
      throw error;
    }

    return doFetch(path, options);
  }
}

async function request(path, options = {}) {
  const method = String(options.method ?? 'GET').toUpperCase();
  const attempts = method === 'GET' || method === 'HEAD' ? 3 : 1;
  let lastError;

  for (let i = 0; i < attempts; i += 1) {
    try {
      return await requestOnce(path, options);
    } catch (error) {
      lastError = error;
      if (i === attempts - 1 || !isTransient(error)) throw error;
      await sleep(280 * (i + 1));
    }
  }

  throw lastError;
}

/* ═══════════════════════════ واسط API ═══════════════════════════ */

export const api = {
  ApiError,

  /* ─── احراز هویت ─── */
  async register(payload) {
    const data = await request('/auth/register', { method: 'POST', body: payload, auth: false });
    return saveSession(data);
  },

  requestOtp: (phone, purpose) =>
    request('/auth/otp/request', { method: 'POST', body: { phone, purpose }, auth: false }),
  verifyOtp: (phone, code, purpose) =>
    request('/auth/otp/verify', { method: 'POST', body: { phone, code, purpose }, auth: false }),
  publicConfig: () => request('/config/public', { auth: false }),

  async login(phone, password) {
    const data = await request('/auth/login', {
      method: 'POST',
      body: { phone, password },
      auth: false,
    });
    return saveSession(data);
  },

  async logout() {
    try {
      await request('/auth/logout', {
        method: 'POST',
        body: {},
      });
    } finally {
      clearSession();
    }
  },

  me: () => request('/auth/me'),

  /* ─── موقعیت ─── */
  ownStatus: () => request('/locations/status'),
  watchList: () => request('/locations/watching'),
  currentLocation: (userId) => request('/locations/current', { query: { userId } }),

  ping: (payload) => request('/locations/ping', { method: 'POST', body: payload }),

  history: (userId, from, to, limit = 2000) =>
    request('/locations/history', {
      query: { userId, from: from.toISOString(), to: to.toISOString(), limit },
    }),

  historyDays: (userId) => request('/locations/history/days', { query: { userId } }),

  deleteHistory: (from, to) =>
    request('/locations/history', {
      method: 'DELETE',
      query: {
        from: from ? from.toISOString() : undefined,
        to: to ? to.toISOString() : undefined,
      },
    }),

  setSharing: (enabled) =>
    request('/locations/sharing', { method: 'PUT', body: { enabled } }),

  /* ─── محدوده‌های امن ─── */
  safeZones: (subjectUserId) => request('/safe-zones', { query: subjectUserId ? { subjectUserId } : undefined }),
  createZone: (payload) => request('/safe-zones', { method: 'POST', body: payload }),
  updateZone: (id, patch) => request(`/safe-zones/${id}`, { method: 'PATCH', body: patch }),
  deleteZone: (id) => request(`/safe-zones/${id}`, { method: 'DELETE' }),
  previewZone: (payload) => request('/safe-zones/preview', { method: 'POST', body: payload }),

  /* ─── سرپرستی ─── */
  guardianships: () => request('/guardianships'),
  createInvite: (permissions) =>
    request('/guardianships/invites', { method: 'POST', body: { permissions } }),
  listInvites: () => request('/guardianships/invites'),
  cancelInvite: (id) => request(`/guardianships/invites/${id}`, { method: 'DELETE' }),
  redeemInvite: (code) => request('/guardianships/redeem', { method: 'POST', body: { code } }),
  updatePermissions: (id, permissions) =>
    request(`/guardianships/${id}`, { method: 'PATCH', body: { permissions } }),
  revokeGuardianship: (id) => request(`/guardianships/${id}`, { method: 'DELETE' }),

  /* ─── هشدارها ─── */
  alerts: (params = {}) => request('/alerts', { query: params }),
  markAlertRead: (id) => request(`/alerts/${id}/read`, { method: 'POST' }),
  markAllAlertsRead: () => request('/alerts/read-all', { method: 'POST' }),
  resolveAlert: (id) => request(`/alerts/${id}/resolve`, { method: 'POST' }),

  /* ─── SOS ─── */
  triggerSos: (payload = {}) => request('/sos', { method: 'POST', body: payload }),
  sosContacts: () => request('/sos/contacts'),
  sosConfig: () => request('/sos/config'),
  activeSos: (userId) => request('/sos/active', { query: { userId } }),

  /* ─── تنظیمات و دستگاه ─── */
  settings: () => request('/settings'),
  updateSettings: (patch) => request('/settings', { method: 'PATCH', body: patch }),
  registerDevice: (payload) => request('/devices', { method: 'POST', body: payload }),

  /* ─── شبیه‌ساز (حالت نمایش) ─── */
  simulatorRoutes: () => request('/simulator/routes'),
  simulatorStatus: () => request('/simulator/status'),
  startSimulator: (payload) => request('/simulator/start', { method: 'POST', body: payload }),
  stopSimulator: () => request('/simulator/stop', { method: 'POST' }),
  simulatorFall: () => request('/simulator/fall', { method: 'POST' }),

  /* ─── مدیریت سامانه ─── */
  submitDocument: (documentType, imageUrl) =>
    request('/documents', { method: 'POST', body: { documentType, imageUrl } }),
  adminOverview: () => request('/admin/overview'),
  adminDocuments: (query = {}) => request('/admin/documents', { query }),
  adminFamilies: () => request('/admin/families'),
  adminAlerts: () => request('/admin/alerts'),
  adminFalls: () => request('/admin/falls'),
  adminSupport: () => request('/admin/support'),
  adminSupportReply: (userId, body) => request(`/admin/support/${userId}/reply`, { method: 'POST', body: { body } }),
  mySupport: () => request('/support/messages'),
  sendSupport: (body) => request('/support/messages', { method: 'POST', body: { body } }),
  sendDocument: (body) => request('/documents', { method: 'POST', body }),
  myDocuments: () => request('/documents/mine'),
  adminApproveDocument: (id) => request(`/admin/documents/${id}/approve`, { method: 'POST' }),
  adminRejectDocument: (id, reason) => request(`/admin/documents/${id}/reject`, { method: 'POST', body: { reason } }),
  adminUsers: (query = {}) => request('/admin/users', { query }),
  adminUser: (id) => request(`/admin/users/${id}`),
  adminSuspendUser: (id, reason) =>
    request(`/admin/users/${id}/suspend`, { method: 'POST', body: { reason } }),
  adminActivateUser: (id) => request(`/admin/users/${id}/activate`, { method: 'POST' }),
  adminDeleteUser: (id) => request(`/admin/users/${id}`, { method: 'DELETE' }),
  adminChangeRole: (id, role) =>
    request(`/admin/users/${id}/role`, { method: 'PATCH', body: { role } }),
  adminDevices: (query = {}) => request('/admin/devices', { query }),
  adminRevokeDevice: (id) => request(`/admin/devices/${id}/revoke`, { method: 'POST' }),
  adminRequestLogs: (query = {}) => request('/admin/logs/requests', { query }),
  adminAuditLogs: (query = {}) => request('/admin/logs/audit', { query }),
  adminPurgeLogs: (olderThanDays) =>
    request('/admin/logs/purge', { method: 'POST', body: { olderThanDays } }),
  adminMetrics: (query = {}) => request('/admin/metrics', { query }),
  adminOutbox: (query = {}) => request('/admin/notifications/outbox', { query }),
  adminRetryOutbox: (id) =>
    request(`/admin/notifications/outbox/${id}/retry`, { method: 'POST' }),

  /* ─── سلامت ─── */
  health: () => fetch('/health').then((r) => r.json()),
};

export { ApiError };
export default api;
