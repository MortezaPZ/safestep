# SafeStep

A safety and tracking system for someone who wants to go out independently, and for the family that needs a reliable alert when something goes wrong.

## Overview

The person can see who is watching and can stop sharing. The family still gets an emergency signal when the person asks for help, and the backend can raise a fall, a geofence exit, or a lost GPS fix.

## Features

- Live location for an active guardianship
- Safe zones, with hysteresis so a noisy GPS fix on the boundary does not flap
- Fall detection trained on SisFall, plus the earlier synthetic dataset kept separate from that evaluation
- Alerts, SOS, and an append-style notification outbox
- A web console for guardians and admins
- A Flutter client for Android and iOS

## Technology Stack

- Node.js 20+ and Express
- PostgreSQL in production
- PGlite for the local test database
- Flutter
- Socket.IO

## Architecture

```
mobile/     Flutter client
web/        Guardian and admin interface
backend/    HTTP API, Socket.IO, geofence and fall services
docs/       Deployment and evaluation notes
```

The API does not import the test runner. Production uses `DB_DRIVER=pg`. Tests use the embedded PostgreSQL-compatible engine so the suite does not need a server.

Fall-model metrics, load-test numbers, and the geofence hysteresis table are in `docs/evaluation/defense-and-metrics.md`. iOS build status is in `docs/ios-build-status.md`. A networked PostgreSQL deployment is in `docs/deployment-postgres.md`.

## Installation

```powershell
cd backend
npm install
npm test
npm start
```

`npm start` runs `node src/server.js`. Do not commit a real `.env`.

The Flutter project is in `mobile/`. An iOS archive needs Xcode on macOS. This Windows tree cannot produce an IPA. The Info.plist permission keys required by location, motion, and background alerts are documented in `docs/ios-build-status.md`.

## Running an evaluation

Use a networked PostgreSQL database and disable the simulator before collecting or reporting measurements:

```env
DB_DRIVER=pg
DATABASE_URL=postgres://<user>:<password>@<host>:5432/<database>
DEMO_MODE=false
```

The PostgreSQL load test rejects PGlite and runs each scenario for at least 60 seconds by default. See `docs/evaluation/defense-and-metrics.md` for which outputs are synthetic and which still need real participants, walks, or phones.

## Usage

Seed and run the API, then open the web console. Guardian accounts, zones, and alerts are part of the backend. The demo-oriented walkthrough with seeded phone numbers lives in the separate `safestep-demo` repository. This repository is the full product tree, including the Flutter app.

## Testing

```bash
cd backend
npm test
```

The backend suite includes unit and integration tests. `mobile/test/` contains three tests: server-address normalization, centered fall-window timing, and the field-evaluation form; this package does not contain 25 mobile tests. All three passed with `flutter test --no-pub`. Direct Pub.dev access returned HTTP 403 in the development environment, so dependencies were resolved through a mirror. A clean environment needs Pub.dev or a compatible mirror for packages such as `image_picker`.

## Limitations

- iOS has not been archived on a Mac in this workspace
- Real-walk position-error samples, independent SUS responses, and FCM phone-delivery latency have not been collected yet
- Map tiles need a network. The API can run without them
- Production secrets must be long random values. The examples in `.env` files are for local use

## License

See the repository license file if one is present.
