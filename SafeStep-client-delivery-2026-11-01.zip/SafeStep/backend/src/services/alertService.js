/**
 * سرویس هشدار — ساخت، توزیع و مدیریت هشدارها.
 *
 * ── قاعده‌ی مرکزی توزیع ──────────────────────────────────────────────────
 * گیرندگان هر هشدار از روی سطح دسترسیِ ثبت‌شده در رابطه‌ی سرپرستی تعیین
 * می‌شوند، نه از روی چیزی که کلاینت ادعا می‌کند. هشدار SOS فقط به کسانی
 * می‌رسد که دسترسی «اضطراری» دارند و بقیه‌ی هشدارها فقط به دارندگان
 * «دریافت هشدار». این فیلتر در کوئری دیتابیس اعمال می‌شود تا امکان
 * فراموش شدنش در لایه‌های بالاتر وجود نداشته باشد.
 */
import {
  ALERT_TYPES,
  ALERT_SEVERITY,
  ALERT_REQUIRED_PERMISSION,
  WS_EVENTS,
} from '../config/constants.js';
import * as alertRepository from '../repositories/alertRepository.js';
import * as guardianshipRepository from '../repositories/guardianshipRepository.js';
import * as userRepository from '../repositories/userRepository.js';
import hub from '../realtime/hub.js';
import telemetryService from './telemetryService.js';
import notificationAdapter from './notificationAdapter.js';
import notificationOutbox from './notificationOutbox.js';
import logger from '../utils/logger.js';
import { forbidden, notFound } from '../utils/errors.js';
import db from '../db/index.js';

const log = logger.child({ module: 'alert' });

const ADMIN_FALL_ALERT_FIELDS = Object.freeze([
  'id',
  'userId',
  'type',
  'severity',
  'title',
  'body',
  'zoneId',
  'createdAt',
]);
const ADMIN_FALL_METADATA_FIELDS = Object.freeze([
  'fallEventId',
  'confidence',
  'feedback',
  'manualReport',
]);

function adminFallAlertPayload(alert) {
  const payload = Object.fromEntries(
    ADMIN_FALL_ALERT_FIELDS
      .filter((field) => Object.hasOwn(alert, field))
      .map((field) => [field, alert[field]]),
  );
  if (alert.subject) {
    payload.subject = {
      id: alert.subject.id,
      fullName: alert.subject.fullName,
      avatarColor: alert.subject.avatarColor,
    };
  }
  if (Object.hasOwn(alert, 'zoneName')) payload.zoneName = alert.zoneName;
  payload.metadata = Object.fromEntries(
    ADMIN_FALL_METADATA_FIELDS
      .filter((field) => Object.hasOwn(alert.metadata ?? {}, field))
      .map((field) => [field, alert.metadata[field]]),
  );
  payload.lat = null;
  payload.lng = null;
  payload.location = null;
  return payload;
}

/* ──────────────────────── متن‌سازی هشدارها ──────────────────────── */

/**
 * ساخت عنوان و متن فارسی هشدار.
 * متن‌ها اینجا متمرکز شده‌اند تا لحن یکدست بماند: خبری و آرام، نه هشدارآمیز.
 * لحن ترسناک در محصولی که هر روز استفاده می‌شود، به بی‌اعتنایی ختم می‌شود.
 */
export function composeAlertMessage(type, context = {}) {
  const name = context.userName ?? 'کاربر';
  const zone = context.zoneName ?? 'محدوده‌ی امن';

  switch (type) {
    case ALERT_TYPES.SOS:
      return {
        title: 'درخواست کمک اضطراری',
        body: `${name} دکمه‌ی اضطراری را فشرده است. لطفاً هرچه سریع‌تر تماس بگیرید.`,
      };

    case ALERT_TYPES.ZONE_EXIT:
      if (context.dwell) {
        const n = Math.round(context.dwellMinutes ?? context.durationMinutes ?? 0);
        return {
          title: 'ماندگاری بیرون از محدوده',
          body: `${name} بیش از ${n} دقیقه خارج از «${zone}» است.`,
        };
      }
      return {
        title: 'خروج از محدوده‌ی امن',
        body: `${name} از «${zone}» خارج شد.`,
      };

    case ALERT_TYPES.ZONE_ENTER:
      return {
        title: 'بازگشت به محدوده‌ی امن',
        body: `${name} به «${zone}» بازگشت.`,
      };

    case ALERT_TYPES.LONG_STOP: {
      const minutes = Math.round(context.durationMinutes ?? 0);
      return {
        title: 'توقف طولانی',
        body: `${name} حدود ${minutes} دقیقه در یک نقطه متوقف بوده است.`,
      };
    }

    case ALERT_TYPES.GPS_LOST: {
      const minutes = Math.round((context.silentSeconds ?? 0) / 60);
      return {
        title: 'قطع ارتباط موقعیت',
        body: `حدود ${minutes} دقیقه است موقعیت ${name} دریافت نشده است.`,
      };
    }

    case ALERT_TYPES.LOW_BATTERY:
      return {
        title: 'باتری کم',
        body: `شارژ باتری دستگاه ${name} به ${context.batteryLevel ?? 0} درصد رسیده است.`,
      };

    case ALERT_TYPES.FALL_DETECTED: {
      const pct = Math.round((context.confidence ?? 0) * 100);
      if (context.manualReport) {
        return {
          title: 'سقوط گزارش‌شده',
          body: `${name} سقوطی را که سامانه تشخیص نداده بود گزارش کرد. لطفاً با او تماس بگیرید.`,
        };
      }
      if (context.auto) {
        return {
          title: 'فراخوان اضطراری',
          body: `سقوط ${name} تشخیص داده شد و فراخوان اضطراری به‌صورت خودکار ارسال شد (اطمینان ${pct}٪).`,
        };
      }
      return {
        title: 'احتمال سقوط',
        body: `احتمال سقوط ${name} تشخیص داده شد (اطمینان ${pct}٪). لطفاً فوراً تماس بگیرید.`,
      };
    }

    default:
      return { title: 'هشدار', body: `رویدادی برای ${name} ثبت شد.` };
  }
}

/* ──────────────────────── ساخت و توزیع ──────────────────────── */

/**
 * ثبت یک هشدار و رساندن آن به اعضای مجاز خانواده.
 *
 * @param {object} params
 * @param {string} params.userId کاربر اصلی که هشدار درباره‌ی اوست
 * @param {string} params.type نوع هشدار
 * @param {{lat?: number, lng?: number}} [params.location]
 * @param {string} [params.zoneId]
 * @param {object} [params.context] داده‌ی لازم برای متن‌سازی
 * @param {object} [params.metadata] داده‌ی ساختاریافته‌ی اضافی
 */
export async function raiseAlert({ userId, type, location, zoneId, context = {}, metadata = {} }) {
  const subject = await userRepository.findById(userId);
  if (!subject) throw notFound('کاربر یافت نشد.');

  const severity = ALERT_SEVERITY[type] ?? 'warning';
  const { title, body } = composeAlertMessage(type, { ...context, userName: subject.fullName });

  const alert = await alertRepository.create({
    userId,
    type,
    severity,
    title,
    body,
    lat: location?.lat ?? null,
    lng: location?.lng ?? null,
    zoneId: zoneId ?? null,
    metadata,
  });

  // گیرندگان بر اساس سطح دسترسی لازم برای این نوع هشدار
  const requiredPermission = ALERT_REQUIRED_PERMISSION[type];
  const recipients = await guardianshipRepository.listRecipientsForPermission(
    userId,
    requiredPermission,
  );
  let familyRecipientIds = recipients.map((r) => r.id);
  let adminRecipientIds = [];
  if (type === ALERT_TYPES.FALL_DETECTED) {
    const { rows: admins } = await db.query(
      `SELECT id FROM users WHERE role = 'admin' AND status = 'active'`,
    );
    adminRecipientIds = admins.map((row) => row.id);
    const adminIds = new Set(adminRecipientIds);
    familyRecipientIds = familyRecipientIds.filter((id) => !adminIds.has(id));
  }
  const recipientIds = [...familyRecipientIds, ...adminRecipientIds];

  const enriched = {
    ...alert,
    subject: {
      id: subject.id,
      fullName: subject.fullName,
      avatarColor: subject.avatarColor,
    },
    zoneName: context.zoneName ?? null,
  };

  // کاربر اصلی هم نسخه‌ی خودش را می‌بیند — او باید بداند چه چیزی
  // درباره‌اش به خانواده گزارش شده است. شفافیت، شرط استقلال است.
  hub.emitToUsers([...familyRecipientIds, userId], WS_EVENTS.ALERT_NEW, enriched);
  if (adminRecipientIds.length > 0) {
    // ادمین فقط داده‌های لازم برای فهم رویداد را می‌گیرد. payload و metadata
    // هر دو allowlist هستند تا مختصات با افزودن فیلدی تازه نشت نکنند.
    const adminAlert = adminFallAlertPayload(enriched);
    hub.emitToUsers(adminRecipientIds, WS_EVENTS.ALERT_NEW, adminAlert);
  }

  const pushPayload = {
    title,
    body,
    severity,
    data: {
      alertId: alert.id,
      type,
      subjectId: userId,
      ...(zoneId ? { zoneId } : {}),
    },
  };

  let delivery;
  if (notificationAdapter.activeDriver() === 'local') {
    delivery = await notificationAdapter.notify(recipientIds, pushPayload);
  } else {
    notificationAdapter.emitInApp(recipientIds, pushPayload, 'fcm');
    const queued = await notificationOutbox.enqueueForRecipients(recipientIds, {
      alertId: alert.id,
      ...pushPayload,
    });
    delivery = { driver: 'fcm', queued: queued.length, sent: 0, failed: 0, fellBack: false };
  }

  // ثبت WebSocket فقط وقتی گیرنده آنلاین است. نتیجه‌ی FCM بعد از تلاش واقعی
  // worker در outbox ثبت می‌شود؛ enqueue را به‌عنوان ارسال موفق نمی‌شماریم.
  const deliveryLatencyMs = Math.max(
    0,
    Math.round(Date.now() - new Date(alert.createdAt).getTime()),
  );

  let websocketSent = 0;
  if (recipientIds.length > 0) {
    for (const recipientUserId of recipientIds) {
      if (!hub.isUserOnline(recipientUserId)) continue;
      telemetryService.recordDelivery({
        alertId: alert.id,
        recipientUserId,
        channel: 'websocket',
        status: 'sent',
        latencyMs: deliveryLatencyMs,
        errorCode: null,
      });
      websocketSent += 1;
    }
  }

  log.info('هشدار ثبت و توزیع شد', {
    alertId: alert.id,
    type,
    severity,
    recipients: recipientIds.length,
    deliveredVia: delivery.driver,
    websocketSent,
    fcmQueued: delivery.queued ?? 0,
    deliveryLatencyMs,
  });

  return { alert: enriched, recipients, delivery };
}

/* ──────────────────────── خواندن و مدیریت ──────────────────────── */

/**
 * فهرست کاربرانی که یک بیننده اجازه‌ی دیدن هشدارهایشان را دارد.
 * شامل خودش (هشدارهای مربوط به خودش) و کاربران اصلی‌ای که دسترسی دارد.
 */
export async function visibleSubjectIds(viewerId) {
  const links = await guardianshipRepository.listPrimariesFor(viewerId);
  const permitted = links
    .filter((l) => l.permissions.includes('receive_alerts') || l.permissions.includes('emergency'))
    .map((l) => l.primaryUserId);

  return [...new Set([viewerId, ...permitted])];
}

export async function listAlerts(viewerId, { types, unreadOnly, limit, before, subjectId } = {}) {
  let subjectIds = await visibleSubjectIds(viewerId);

  // اگر بیننده روی یک کاربر خاص فیلتر کرده، باید در فهرست مجازش باشد
  if (subjectId) {
    if (!subjectIds.includes(subjectId)) {
      throw forbidden('شما به هشدارهای این کاربر دسترسی ندارید.');
    }
    subjectIds = [subjectId];
  }

  const [alerts, counts, unreadCount] = await Promise.all([
    alertRepository.list(subjectIds, viewerId, { types, unreadOnly, limit, before }),
    alertRepository.countsByType(subjectIds),
    alertRepository.countUnread(subjectIds, viewerId),
  ]);

  const links = await guardianshipRepository.listPrimariesFor(viewerId);
  const emergencySubjects = new Set(
    links.filter((link) => link.permissions.includes('emergency')).map((link) => link.primaryUserId),
  );
  const visibleAlerts = alerts.filter((item) => {
    const subject = item.userId ?? item.user_id;
    if (subject === viewerId) return true;
    if (item.type === 'sos' || item.type === 'fall_detected') {
      return emergencySubjects.has(subject);
    }
    return true;
  });

  const named = await Promise.all(visibleAlerts.map(async (item) => {
    if (item.userId !== viewerId && item.user_id !== viewerId) return item;
    const subjectId = item.userId ?? item.user_id;
    const { rows } = await db.query(
      `SELECT u.full_name FROM guardianships g
         JOIN users u ON u.id = g.guardian_user_id
        WHERE g.primary_user_id = $1 AND g.status = 'active'`,
      [subjectId],
    );
    const names = rows.map((row) => row.full_name).join('، ') || 'ناظر';
    const type = item.type;
    let body = `این رویداد به ${names} ارسال شد.`;
    if (type === 'gps_lost') body = `قطع موقعیت شما به ${names} ارسال شد.`;
    if (type === 'low_battery') body = `شارژ باتری دستگاه شما کم شده و به ${names} ارسال شد.`;
    if (type === 'zone_exit') body = `خروج شما از محدودهٔ امن به ${names} ارسال شد.`;
    if (type === 'zone_enter') body = `شما در محدودهٔ امن هستید. این خبر به ${names} ارسال شد.`;
    if (type === 'fall_detected') body = `فراخوان اضطراری به ${names} و مدیریت ارسال شد.`;
    return { ...item, body, canResolve: false };
  }));

  return { alerts: named, countsByType: counts, unreadCount };
}

export async function markRead(alertId, viewerId) {
  const alert = await alertRepository.findById(alertId);
  if (!alert) throw notFound('هشدار یافت نشد.');

  const allowed = await visibleSubjectIds(viewerId);
  if (!allowed.includes(alert.userId)) {
    throw forbidden('شما به این هشدار دسترسی ندارید.');
  }

  await alertRepository.markRead(alertId, viewerId);
  hub.emitToUser(viewerId, WS_EVENTS.ALERT_READ, { alertId });

  // لحظه‌ای که یک انسان واقعاً هشدار را دید. بقیه‌ی زنجیره فقط تأخیر ماشین
  // را می‌سنجد؛ این تنها سنجه‌ی «تأخیر تا اطلاعِ مراقب» است.
  await telemetryService.acknowledgeAlert(alertId, viewerId);

  return { ok: true };
}

export async function markAllRead(viewerId) {
  const subjectIds = await visibleSubjectIds(viewerId);
  const count = await alertRepository.markAllRead(subjectIds, viewerId);
  return { ok: true, count };
}

/**
 * بستن یک هشدار.
 * هم کاربر اصلی می‌تواند هشدار خودش را ببندد (مثلاً SOS اشتباهی)،
 * هم عضو خانواده‌ای که به آن دسترسی دارد.
 */
export async function resolveAlert(alertId, viewerId) {
  const alert = await alertRepository.findById(alertId);
  if (!alert) throw notFound('هشدار یافت نشد.');

  const allowed = await visibleSubjectIds(viewerId);
  if (!allowed.includes(alert.userId)) {
    throw forbidden('شما به این هشدار دسترسی ندارید.');
  }
  if (viewerId === alert.userId) {
    throw forbidden('رسیدگی هشدار فقط برای ناظر است. شما فقط وضعیت ارسال را می‌بینید.');
  }

  const resolved = await alertRepository.resolve(alertId, viewerId);
  if (!resolved) return alert; // از قبل بسته شده بود

  const recipients = await guardianshipRepository.listRecipientsForPermission(
    alert.userId,
    ALERT_REQUIRED_PERMISSION[alert.type],
  );

  hub.emitToUsers(
    [...recipients.map((r) => r.id), alert.userId],
    WS_EVENTS.ALERT_NEW,
    { ...resolved, isResolution: true },
  );

  log.info('هشدار بسته شد', { alertId, by: viewerId });
  return resolved;
}

export default {
  raiseAlert,
  listAlerts,
  markRead,
  markAllRead,
  resolveAlert,
  visibleSubjectIds,
  composeAlertMessage,
};
