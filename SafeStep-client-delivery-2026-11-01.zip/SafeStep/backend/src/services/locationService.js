/**
 * سرویس موقعیت — خط لوله‌ی اصلی سیستم.
 *
 * هر پینگ موقعیت از این مسیر عبور می‌کند:
 *
 *   ثبت پینگ
 *     └→ به‌روزرسانی وضعیت دستگاه (باتری)
 *     └→ پخش زنده به اعضای مجاز خانواده
 *     └→ موتور Geofence  → هشدار خروج/بازگشت
 *     └→ تشخیص توقف طولانی → هشدار توقف
 *     └→ بررسی باتری کم → هشدار باتری
 *
 * ── تنش استقلال و ایمنی، به‌صورت کد ─────────────────────────────────────
 * وقتی کاربر اشتراک موقعیت را قطع می‌کند:
 *   • پینگ‌ها همچنان ثبت می‌شوند (تاریخچه‌ی خودِ کاربر، متعلق به خودِ اوست)
 *   • هیچ موقعیتی به خانواده پخش نمی‌شود
 *   • هیچ هشدار مبتنی بر موقعیت تولید نمی‌شود — چون خودِ هشدار «خروج از خانه»
 *     هم یک نشت موقعیت است، حتی اگر مختصات را نفرستد
 *   • اما SOS همچنان کار می‌کند، چون کاربر خودش آن را آغاز کرده است
 */
import env from '../config/env.js';
import {
  ALERT_TYPES,
  PERMISSIONS,
  WS_EVENTS,
  ZONE_STATE,
} from '../config/constants.js';
import * as locationRepository from '../repositories/locationRepository.js';
import * as safeZoneRepository from '../repositories/safeZoneRepository.js';
import * as guardianshipRepository from '../repositories/guardianshipRepository.js';
import * as userRepository from '../repositories/userRepository.js';
import * as deviceRepository from '../repositories/deviceRepository.js';
import * as alertRepository from '../repositories/alertRepository.js';
import { evaluateZone, isCooldownElapsed, summarizeState, isScheduleActive } from './geofenceEngine.js';
import { detectStop, shouldAlertStop, detectGpsLost } from './stopDetector.js';
import { raiseAlert } from './alertService.js';
import telemetryService from './telemetryService.js';
import logRepository from '../repositories/logRepository.js';
import hub from '../realtime/hub.js';
import logger from '../utils/logger.js';
import { forbidden, notFound } from '../utils/errors.js';

const log = logger.child({ module: 'location' });

const geofenceConfig = {
  hysteresisM: env.geofence.hysteresisM,
  debounceCount: env.geofence.debounceCount,
  cooldownSec: env.geofence.cooldownSec,
};

/** آستانه‌ی هشدار باتری کم. یک بار در هر عبور از این حد هشدار داده می‌شود. */
const LOW_BATTERY_THRESHOLD = 15;

/* ─────────────────────────── دریافت پینگ ─────────────────────────── */

/**
 * ثبت و پردازش یک پینگ موقعیت.
 *
 * @param {string} userId
 * @param {object} data lat, lng, accuracyM, speedMps, headingDeg, batteryLevel, isSimulated, recordedAt
 * @returns {Promise<object>} پینگ ثبت‌شده به‌همراه خلاصه‌ی وضعیت و هشدارهای تولیدشده
 */
/**
 * زمانِ آخرین پینگِ هر کاربر، فقط برای محاسبه‌ی «فاصله از پینگ قبلی».
 *
 * عمداً در حافظه نگه داشته می‌شود و نه در دیتابیس: یک کوئری اضافه به‌ازای هر
 * پینگ، به تأخیری اضافه می‌کند که همین‌جا داریم اندازه‌اش می‌گیریم. اگر سرور
 * ری‌استارت شود، اولین پینگِ هر کاربر بدون این سنجه ثبت می‌شود — که برای یک
 * سنجه‌ی آماری بی‌اهمیت است.
 */
const lastPingAt = new Map();

function gapSecondsFor(userId, recordedAt) {
  const previous = lastPingAt.get(userId);
  const current = new Date(recordedAt).getTime();
  lastPingAt.set(userId, current);
  if (lastPingAt.size > 10_000) lastPingAt.clear();
  if (!previous || current <= previous) return null;
  return Math.round((current - previous) / 1000);
}

/**
 * ثبت سنجه‌های یک پینگ.
 * accuracy_m دقت اعلامی GPS است. خطای نقطه‌ی مرجع فقط در ارزیابی میدانیِ
 * صریح ثبت می‌شود؛ حرکت عادی کاربر نمونه‌ی مرجع نیست.
 */
async function recordPingTelemetry(userId, ping, { processMs, batchSize }) {
  const recordedMs = new Date(ping.recordedAt).getTime();
  const receivedMs = ping.receivedAt ? new Date(ping.receivedAt).getTime() : Date.now();

  const e2eLatencyMs = Math.max(0, Math.round(receivedMs - recordedMs));

  telemetryService.recordLocation({
    userId,
    pingId: ping.id,
    recordedAt: ping.recordedAt,
    e2eLatencyMs,
    processMs,
    accuracyM: ping.accuracyM,
    provider: ping.provider,
    source: ping.source,
    batchSize,
    isQueuedReplay: ping.isQueuedReplay,
    gapSec: gapSecondsFor(userId, ping.recordedAt),
  });
}

async function processPing(userId, data, insertedPing = null) {
  const startedAt = process.hrtime.bigint();
  const settings = await userRepository.getSettings(userId);
  if (!settings) throw notFound('کاربر یافت نشد.');

  const ping = insertedPing ?? await locationRepository.insertPing({ userId, ...data });

  if (data.batteryLevel !== undefined && data.batteryLevel !== null) {
    await deviceRepository.touch(userId, {
      batteryLevel: data.batteryLevel,
      installId: data.deviceInstallId,
    });
  }

  const sharingEnabled = settings.locationSharingEnabled;
  const generatedAlerts = [];

  // ── پخش زنده ────────────────────────────────────────────────────────
  const viewers = sharingEnabled
    ? await guardianshipRepository.listRecipientsForPermission(userId, PERMISSIONS.VIEW_LOCATION)
    : [];

  // کاربر اصلی همیشه موقعیت خودش را می‌بیند، فارغ از تنظیم اشتراک‌گذاری
  hub.emitToUsers([...viewers.map((v) => v.id), userId], WS_EVENTS.LOCATION_UPDATE, {
    userId,
    lat: ping.lat,
    lng: ping.lng,
    accuracyM: ping.accuracyM,
    speedMps: ping.speedMps,
    headingDeg: ping.headingDeg,
    batteryLevel: ping.batteryLevel,
    isSimulated: ping.isSimulated,
    recordedAt: ping.recordedAt,
    sharingEnabled,
  });

  // ── موتور Geofence ──────────────────────────────────────────────────
  const zoneResults = await evaluateGeofences(userId, ping, {
    allowAlerts: sharingEnabled && settings.alertTypes.includes(ALERT_TYPES.ZONE_EXIT),
    userName: null,
  });
  generatedAlerts.push(...zoneResults.alerts);

  // ── تشخیص توقف طولانی ────────────────────────────────────────────────
  if (sharingEnabled && settings.alertTypes.includes(ALERT_TYPES.LONG_STOP)) {
    const stopAlert = await evaluateLongStop(userId, settings, ping);
    if (stopAlert) generatedAlerts.push(stopAlert);
  }

  // ── باتری کم ────────────────────────────────────────────────────────
  if (
    sharingEnabled &&
    settings.alertTypes.includes(ALERT_TYPES.LOW_BATTERY) &&
    typeof ping.batteryLevel === 'number' &&
    ping.batteryLevel <= LOW_BATTERY_THRESHOLD
  ) {
    const last = await alertRepository.findLastOfType(userId, ALERT_TYPES.LOW_BATTERY);
    // یک هشدار در هر ۶ ساعت کافی است
    const elapsed = last ? Date.now() - new Date(last.createdAt).getTime() : Infinity;
    if (elapsed > 6 * 3600 * 1000) {
      const { alert } = await raiseAlert({
        userId,
        type: ALERT_TYPES.LOW_BATTERY,
        location: { lat: ping.lat, lng: ping.lng },
        context: { batteryLevel: ping.batteryLevel },
        metadata: { batteryLevel: ping.batteryLevel },
      });
      generatedAlerts.push(alert);
    }
  }

  await recordPingTelemetry(userId, ping, {
    processMs: Math.max(1, Math.round(Number(process.hrtime.bigint() - startedAt) / 1e6)),
    batchSize: data.batchSize ?? 1,
  });

  return {
    ping,
    status: zoneResults.summary,
    zones: zoneResults.states,
    alerts: generatedAlerts,
    sharingEnabled,
  };
}

export async function ingestPing(userId, data) {
  return processPing(userId, data);
}

/**
 * تخلیه‌ی صف آفلاین اپ — درج دسته‌ای پینگ‌ها.
 *
 * ── چرا فقط جدیدترین پینگ وارد خط لوله‌ی هشدار می‌شود ────────────────────
 * دسته معمولاً دقایقی از حرکتِ گذشته است. اگر موتور Geofence روی تک‌تکِ
 * آن‌ها اجرا شود، کاربری که نیم‌ساعت پیش از خانه بیرون رفته و برگشته، همین
 * حالا چند هشدارِ منقضی دریافت می‌کند و مراقب را بی‌دلیل نگران می‌کند.
 * تاریخچه کامل ذخیره می‌شود (نقشه و مسیر درست است) اما وضعیتِ لحظه‌ای فقط
 * از آخرین نقطه محاسبه می‌شود — که همان چیزی است که «الان کجاست» یعنی.
 *
 * @param {string} userId
 * @param {{pings: object[]}} payload
 */
export async function ingestBatch(userId, { pings, deviceInstallId }) {
  const startedAt = process.hrtime.bigint();

  const settings = await userRepository.getSettings(userId);
  if (!settings) throw notFound('کاربر یافت نشد.');

  const marked = pings.map((p) => ({ ...p, isQueuedReplay: p.isQueuedReplay ?? true }));
  const { inserted, duplicates } = await locationRepository.insertPingsBatch(userId, marked);

  const processMs = Math.max(1, Math.round(Number(process.hrtime.bigint() - startedAt) / 1e6));

  // آخرین پینگ در اینجا ثبت نمی‌شود؛ چند خط پایین‌تر از مسیر کاملِ ingestPing
  // عبور می‌کند و سنجه‌اش همان‌جا — همراه با زمان پردازش واقعی — ثبت می‌شود.
  for (const ping of inserted.slice(0, -1)) {
    await recordPingTelemetry(userId, ping, { processMs: null, batchSize: pings.length });
  }

  // هیچ پینگ تازه‌ای درج نشد (همه تکراری بودند) — پاسخ موفق است تا کلاینت
  // صفش را خالی کند، ولی هیچ پردازشی لازم نیست.
  if (inserted.length === 0) {
    return { accepted: 0, duplicates, processMs, status: null, alerts: [] };
  }

  const latest = inserted[inserted.length - 1];

  // آخرین نقطه از مسیر عادی عبور می‌کند: پخش زنده، Geofence، توقف و باتری.
  // چون خودش قبلاً درج شده، با client_uuid همان ردیف برمی‌گردد و ردیف تکراری ساخته نمی‌شود.
  const result = await processPing(userId, {
    lat: latest.lat,
    lng: latest.lng,
    accuracyM: latest.accuracyM,
    speedMps: latest.speedMps,
    headingDeg: latest.headingDeg,
    batteryLevel: latest.batteryLevel,
    isSimulated: latest.isSimulated,
    source: latest.source,
    provider: latest.provider,
    isQueuedReplay: latest.isQueuedReplay,
    recordedAt: latest.recordedAt,
    batchSize: pings.length,
    deviceInstallId,
  }, latest);

  log.info('دسته‌ی پینگ آفلاین دریافت شد', {
    userId,
    received: pings.length,
    accepted: inserted.length,
    duplicates,
    ms: processMs,
  });

  return {
    accepted: inserted.length,
    duplicates,
    processMs,
    status: result.status,
    alerts: result.alerts,
    sharingEnabled: result.sharingEnabled,
  };
}

/* ─────────────────────────── موتور Geofence ─────────────────────────── */

/**
 * ارزیابی موقعیت در برابر تمام محدوده‌های فعال کاربر و ثبت وضعیت جدید.
 * هشدار تنها وقتی صادر می‌شود که هر سه شرط برقرار باشد:
 *   تغییر وضعیت تأیید شده باشد، رویداد قابل گزارش باشد، و دوره‌ی خاموشی گذشته باشد.
 */
async function evaluateGeofences(userId, ping, { allowAlerts }) {
  const zones = await safeZoneRepository.listByUser(userId, { onlyActive: true });

  if (zones.length === 0) {
    return { summary: summarizeState([]), states: [], alerts: [] };
  }

  /**
   * مرجعِ زمانِ این ارزیابی: زمان ثبتِ خودِ پینگ، نه زمان رسیدنش به سرور.
   * برای پینگ زنده این دو یکی است، ولی برای بازپخشِ صف آفلاین پینگ ممکن است
   * دقایق پیش ثبت شده باشد. ماندگاریِ واقعی باید از لحظه‌ای شمارش شود که
   * کاربر واقعاً بیرون از محدوده قرار گرفته، نه از لحظه‌ای که اینترنتش
   * برگشته و سرور پینگ را دیده.
   */
  const at = ping.recordedAt ? new Date(ping.recordedAt) : new Date();

  const previousStates = await safeZoneRepository.listStatesForUser(userId);
  const stateByZone = new Map(previousStates.map((s) => [s.zoneId, s]));

  const alerts = [];
  const states = [];

  for (const zone of zones) {
    const previous = stateByZone.get(zone.id) ?? null;
    const result = evaluateZone({ lat: ping.lat, lng: ping.lng }, zone, previous, geofenceConfig);
    const scheduleOn = isScheduleActive(zone.schedule, at);
    const enterOk = zone.alertOnEnter !== false;
    const exitOk = zone.alertOnExit !== false;

    const reportable = (result.event === 'exit' && exitOk) || (result.event === 'enter' && enterOk);
    const cooldownOk = isCooldownElapsed(previous?.lastAlertAt, geofenceConfig, at.getTime());
    const willAlert = Boolean(allowAlerts && scheduleOn && reportable && cooldownOk);

    let dwellAlerted = false;
    if (
      allowAlerts &&
      scheduleOn &&
      zone.dwellAlertMinutes &&
      result.state === 'outside'
    ) {
      const since = previous?.lastTransitionAt ? new Date(previous.lastTransitionAt).getTime() : null;
      const dwellMs = zone.dwellAlertMinutes * 60 * 1000;
      const lastDwell = previous?.lastDwellAlertAt ? new Date(previous.lastDwellAlertAt).getTime() : 0;
      if (since && at.getTime() - since >= dwellMs && lastDwell < since) {
        dwellAlerted = true;
      }
    }

    await safeZoneRepository.upsertZoneState({
      userId,
      zoneId: zone.id,
      state: result.state,
      consecutiveCount: result.consecutiveCount,
      pendingState: result.pendingState,
      lastDistanceM: result.distanceM,
      transitioned: result.transitioned,
      alerted: willAlert,
      dwellAlerted,
      evaluatedAt: at,
    });

    states.push({
      zoneId: zone.id,
      zoneName: zone.name,
      state: result.state,
      distanceM: Math.round(result.distanceM),
      radiusM: zone.radiusM,
      thresholds: result.thresholds,
    });

    if (result.transitioned) {
      // تغییر وضعیت همیشه به کاربر اصلی و بینندگان مجاز اعلام می‌شود،
      // حتی وقتی هشدار رسمی صادر نمی‌شود (مثلاً اولین ارزیابی)
      const viewers = allowAlerts
        ? await guardianshipRepository.listRecipientsForPermission(userId, PERMISSIONS.VIEW_LOCATION)
        : [];
      hub.emitToUsers([...viewers.map((v) => v.id), userId], WS_EVENTS.ZONE_STATE, {
        userId,
        zoneId: zone.id,
        zoneName: zone.name,
        state: result.state,
        distanceM: Math.round(result.distanceM),
      });
    }

    if (willAlert) {
      const { alert } = await raiseAlert({
        userId,
        type: result.event === 'exit' ? ALERT_TYPES.ZONE_EXIT : ALERT_TYPES.ZONE_ENTER,
        location: { lat: ping.lat, lng: ping.lng },
        zoneId: zone.id,
        context: { zoneName: zone.name },
        metadata: {
          distanceM: Math.round(result.distanceM),
          radiusM: zone.radiusM,
          exitThresholdM: Math.round(result.thresholds.exitThresholdM),
          enterThresholdM: Math.round(result.thresholds.enterThresholdM),
          isSimulated: ping.isSimulated,
        },
      });
      alerts.push(alert);

      log.info('تغییر وضعیت محدوده تأیید شد', {
        userId,
        zoneId: zone.id,
        event: result.event,
      });
    } else if (reportable && !cooldownOk) {
      log.debug('هشدار به دلیل دوره‌ی خاموشی صادر نشد', { userId, zoneId: zone.id });
    }

    if (dwellAlerted && !willAlert) {
      const minutes = zone.dwellAlertMinutes;
      const { alert } = await raiseAlert({
        userId,
        type: ALERT_TYPES.ZONE_EXIT,
        location: { lat: ping.lat, lng: ping.lng },
        zoneId: zone.id,
        context: { zoneName: zone.name, dwell: true, dwellMinutes: minutes },
        metadata: { dwellMinutes: minutes, isSimulated: ping.isSimulated },
      });
      alerts.push(alert);
    }
  }

  return { summary: summarizeState(states), states, alerts };
}

/* ─────────────────────── تشخیص توقف طولانی ─────────────────────── */

async function evaluateLongStop(userId, settings, ping) {
  const windowMinutes = settings.longStopMinutes;
  const pings = await locationRepository.findRecentWindow(userId, windowMinutes);

  const result = detectStop(pings, {
    windowMinutes,
    radiusM: settings.longStopRadiusM,
    minPings: env.stopDetect.minPings,
  });

  if (!result.isStopped) return null;

  const last = await alertRepository.findLastOfType(userId, ALERT_TYPES.LONG_STOP);
  if (!shouldAlertStop(last?.createdAt, { windowMinutes })) return null;

  const { alert } = await raiseAlert({
    userId,
    type: ALERT_TYPES.LONG_STOP,
    location: { lat: ping.lat, lng: ping.lng },
    context: { durationMinutes: result.durationMinutes },
    metadata: {
      durationMinutes: result.durationMinutes,
      dispersionM: result.dispersionM,
      pingCount: result.pingCount,
      radiusM: settings.longStopRadiusM,
    },
  });

  log.info('توقف طولانی تشخیص داده شد', {
    userId,
    durationMinutes: result.durationMinutes,
    dispersionM: result.dispersionM,
  });

  return alert;
}

/* ─────────────────────── خواندن موقعیت (با کنترل دسترسی) ─────────────────────── */

/**
 * بررسی اینکه بیننده اجازه‌ی دیدن موقعیت یک کاربر را دارد یا نه.
 * سه شرط: خودِ کاربر باشد، یا رابطه‌ی فعال با دسترسی view_location داشته باشد،
 * و مهم‌تر از همه: کاربر اصلی اشتراک‌گذاری را خاموش نکرده باشد.
 */
export async function assertCanViewLocation(viewerId, subjectId) {
  if (viewerId === subjectId) return { allowed: true, sharingEnabled: true, isSelf: true };

  const permitted = await guardianshipRepository.hasPermission(
    subjectId,
    viewerId,
    PERMISSIONS.VIEW_LOCATION,
  );
  if (!permitted) throw forbidden('شما به موقعیت این کاربر دسترسی ندارید.');

  const settings = await userRepository.getSettings(subjectId);
  if (!settings) throw notFound('کاربر یافت نشد.');

  return { allowed: true, sharingEnabled: settings.locationSharingEnabled, isSelf: false };
}

/**
 * آخرین موقعیت یک کاربر.
 * اگر اشتراک‌گذاری خاموش باشد، به‌جای خطا یک پاسخ صریح «مخفی» برمی‌گردانیم
 * تا رابط کاربری بتواند حالت محترمانه‌ی «موقعیت مخفی شد» را نشان دهد،
 * نه پیام خطا. تفاوت این دو، تفاوت حس نظارت و حس احترام است.
 */
export async function getCurrentLocation(viewerId, subjectId) {
  const access = await assertCanViewLocation(viewerId, subjectId);

  if (!access.sharingEnabled) {
    const override = await guardianshipRepository.isMainSupervisor(viewerId, subjectId);
    if (!override) {
      return {
        userId: subjectId,
        hidden: true,
        reason: 'sharing_disabled',
        message: 'کاربر اشتراک‌گذاری موقعیت را موقتاً خاموش کرده است.',
        location: null,
        status: null,
      };
    }
  }

  const [ping, zoneStates] = await Promise.all([
    locationRepository.findLatest(subjectId),
    safeZoneRepository.listStatesForUser(subjectId),
  ]);

  const gps = detectGpsLost(ping?.recordedAt, env.gpsLostAfterSec);

  return {
    userId: subjectId,
    hidden: false,
    location: ping,
    status: summarizeState(zoneStates),
    zones: zoneStates,
    gps: { isStale: gps.isLost, silentSeconds: gps.silentSeconds },
  };
}

/** آخرین موقعیت همه‌ی کاربرانی که بیننده به آن‌ها دسترسی دارد — برای داشبورد خانواده. */
export async function getWatchList(viewerId) {
  const links = await guardianshipRepository.listPrimariesFor(viewerId);
  const visible = links.filter((l) => l.permissions.includes(PERMISSIONS.VIEW_LOCATION));

  const results = await Promise.all(
    visible.map(async (link) => {
      const current = await getCurrentLocation(viewerId, link.primaryUserId);
      return {
        guardianshipId: link.id,
        permissions: link.permissions,
        isMainSupervisor: link.isMainSupervisor === true,
        user: link.primaryUser,
        ...current,
        isOnline: hub.isUserOnline(link.primaryUserId),
      };
    }),
  );

  return results;
}

export async function getHistory(viewerId, subjectId, { from, to, limit }) {
  const access = await assertCanViewLocation(viewerId, subjectId);
  if (!access.isSelf) {
    const emergency = await guardianshipRepository.hasPermission(
      subjectId,
      viewerId,
      PERMISSIONS.EMERGENCY,
    );
    if (!emergency) {
      throw forbidden('تاریخچه مسیر فقط برای ناظر با دسترسی اضطراری است.');
    }
  }

  if (!access.sharingEnabled && !access.isSelf) {
    const main = await guardianshipRepository.isMainSupervisor(viewerId, subjectId);
    if (!main) {
      return { hidden: true, reason: 'sharing_disabled', points: [], stats: null };
    }
  }

  const [points, stats] = await Promise.all([
    locationRepository.findHistory(subjectId, { from, to, limit }),
    locationRepository.dayStats(subjectId, from, to),
  ]);

  return { hidden: false, points, stats };
}

export async function getHistoryDays(viewerId, subjectId) {
  const access = await assertCanViewLocation(viewerId, subjectId);
  if (!access.isSelf) {
    const emergency = await guardianshipRepository.hasPermission(
      subjectId,
      viewerId,
      PERMISSIONS.EMERGENCY,
    );
    if (!emergency) throw forbidden('تاریخچه مسیر فقط برای ناظر با دسترسی اضطراری است.');
    if (!access.sharingEnabled && !(await guardianshipRepository.isMainSupervisor(viewerId, subjectId))) {
      return [];
    }
  }
  return locationRepository.listHistoryDays(subjectId);
}

/**
 * حذف تاریخچه — فقط توسط خودِ کاربر.
 * حتی عضو خانواده با دسترسی اضطراری هم نمی‌تواند تاریخچه‌ی کسی را پاک کند؛
 * این داده متعلق به کاربر اصلی است.
 */
export async function deleteHistory(userId, { from, to } = {}) {
  const deleted = await locationRepository.deleteHistory(userId, { from, to });
  log.info('تاریخچه‌ی موقعیت حذف شد', { userId, deletedRows: deleted, scoped: Boolean(from || to) });
  return { deleted };
}

/**
 * تغییر وضعیت اشتراک‌گذاری موقعیت.
 * به محض خاموش شدن، به همه‌ی بینندگان اطلاع داده می‌شود تا نقشه‌شان
 * بلافاصله به حالت «مخفی» برود — بدون نیاز به تازه‌سازی صفحه.
 */
export async function setLocationSharing(userId, enabled) {
  const settings = await userRepository.updateSettings(userId, {
    locationSharingEnabled: enabled,
  });

  const viewers = await guardianshipRepository.listRecipientsForPermission(
    userId,
    PERMISSIONS.VIEW_LOCATION,
  );

  hub.emitToUsers([...viewers.map((v) => v.id), userId], WS_EVENTS.SHARING_CHANGED, {
    userId,
    sharingEnabled: enabled,
    at: new Date().toISOString(),
  });

  log.info('وضعیت اشتراک‌گذاری موقعیت تغییر کرد', { userId, enabled, viewers: viewers.length });

  return settings;
}

/** خلاصه‌ی وضعیت کاربر برای کارت بالای داشبورد خودش. */
export async function getOwnStatus(userId) {
  const [ping, zoneStates, settings, zones] = await Promise.all([
    locationRepository.findLatest(userId),
    safeZoneRepository.listStatesForUser(userId),
    userRepository.getSettings(userId),
    safeZoneRepository.listByUser(userId, { onlyActive: true }),
  ]);

  const gps = detectGpsLost(ping?.recordedAt, env.gpsLostAfterSec);
  const summary = summarizeState(zoneStates);

  const viewers = await guardianshipRepository.listRecipientsForPermission(
    userId,
    PERMISSIONS.VIEW_LOCATION,
  );

  return {
    location: ping,
    status: summary.status,
    statusReason: summary.reason,
    insideZones: summary.insideZones.map((z) => ({ zoneId: z.zoneId, zoneName: z.zoneName })),
    zones,
    zoneStates,
    gps: { isStale: gps.isLost, silentSeconds: gps.silentSeconds },
    sharing: {
      enabled: settings?.locationSharingEnabled ?? true,
      // بنر «چه کسانی شما را می‌بینند» از همین می‌آید
      viewerCount: settings?.locationSharingEnabled ? viewers.length : 0,
      viewers: settings?.locationSharingEnabled ? viewers : [],
    },
    batteryLevel: ping?.batteryLevel ?? null,
  };
}

/** Raise one GPS-lost alert per stale-ping period for opted-in, shared users. */
export async function checkGpsLostAlerts(now = Date.now()) {
  const targets = await locationRepository.gpsWatchTargets();
  let raised = 0;
  for (const target of targets) {
    const gps = detectGpsLost(target.recordedAt, env.gpsLostAfterSec, now);
    if (!gps.isLost) continue;
    const last = await alertRepository.findLastOfType(target.userId, ALERT_TYPES.GPS_LOST);
    if (last && new Date(last.createdAt).getTime() >= new Date(target.recordedAt).getTime()) continue;
    await raiseAlert({
      userId: target.userId,
      type: ALERT_TYPES.GPS_LOST,
      context: { silentSeconds: gps.silentSeconds },
      metadata: { silentSeconds: gps.silentSeconds },
    });
    raised += 1;
  }
  return raised;
}

export default {
  ingestPing,
  ingestBatch,
  getCurrentLocation,
  getWatchList,
  getHistory,
  getHistoryDays,
  deleteHistory,
  setLocationSharing,
  getOwnStatus,
  checkGpsLostAlerts,
  assertCanViewLocation,
};
